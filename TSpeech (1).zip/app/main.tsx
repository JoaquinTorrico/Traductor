import Button from "../components/control/button";
import { Translate, translate_add, translate_delete, TranslateDto, Usuario, usuario_archivos } from "../hooks/dataBaseInteraction";
import { saveTextToPDF } from "../hooks/saveToPDF";
import { translateAudioToText } from "../hooks/speechRecognition";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Timestamp } from "firebase/firestore/lite";
import { useEffect, useState } from "react";
import { ScrollView, View, Text, TouchableOpacity, StyleSheet, Image } from "react-native";
import { router } from 'expo-router';

export default function Main() {
  const [openedCard, setOpenedCard] = useState<Translate | undefined>(undefined);
  const [files, setFiles] = useState<TranslateDto[] | undefined>(undefined);
  const [user, setUser] = useState<Usuario | undefined>(undefined);

  useEffect(() => {
    AsyncStorage.getItem("USER").then(json => {
      const user = JSON.parse(json ?? '{}');
      setUser(user);
      usuario_archivos(user.Usuario).then(files => setFiles(files as TranslateDto[]));
    });
  }, []);

  const onQueryUpload = () => {
    translateAudioToText().then(res => {
      if (!res) return;
      translate_add({ Usuario: user!.Usuario, Fecha: Timestamp.now(), Audioname: res.audioFile.assets[0].name, Translate: res.transcript })
        .then(() => {
          usuario_archivos(user!.Usuario).then(files => setFiles(files as TranslateDto[]));
        });
    });
  };

  const onDownloadPDF = (text: string) => {
    saveTextToPDF(text).then(() => {});
  };

  const onDelete = (id: string) => {
    translate_delete(id).then(() => 
      usuario_archivos(user!.Usuario).then(files => setFiles(files as TranslateDto[]))
    );
  };

  return (
    <View style={styles.container}>
      {/* Imagen en la parte superior */}
      <View style={styles.imageContainer}>
        <Image
          source={require('../assets/images/asistente.png')} 
          style={styles.image}
          resizeMode="contain"
        />
      </View>

      {/* Botones justo debajo de la imagen */}
      <View style={styles.buttonContainer}>
        <Button 
          buttonStyles={styles.exitButton} 
          titleStyle={styles.buttonText} // Añadido para el texto negro
          onPress={() => router.navigate('/login')} 
          title="Salir" 
        />
        <Button 
          buttonStyles={styles.uploadButton} 
          titleStyle={styles.buttonText} // Añadido para el texto negro
          onPress={onQueryUpload} 
          title="Cargar Audio" 
        />
      </View>

      <ScrollView style={styles.scrollView}>
        {files?.map((file, index) => (
          <TouchableOpacity key={index} onPress={() => setOpenedCard(file)}>
            <View style={[styles.card, { backgroundColor: openedCard === file ? '#d4d4d4' : '#f5f5f5' }]}>
              <Text style={styles.cardText}>{"Archivo : " + file.Audioname}</Text>
              <TouchableOpacity onPress={() => onDelete(file.id)}>
                <Image source={require('../assets/images/DELETE.png')} style={styles.icon} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => onDownloadPDF(file.Translate)}>
                <Image source={require('../assets/images/PDF.png')} style={styles.icon} />
              </TouchableOpacity>
            </View>
            {openedCard === file && (
              <View style={styles.detailCard}>
                <Text style={styles.detailText}>{file.Translate}</Text>
              </View>
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1F232C',
    alignItems: 'center',
  },
  scrollView: {
    width: '90%',
    paddingBottom: 100, // Ajusta para que no se superponga con los botones
  },
  buttonContainer: {
    width: '500%',
    alignItems: 'center',
    padding: 1,
    marginBottom: 20, // Espacio entre los botones y la lista
  },
  exitButton: {
    width: "80%",
    marginBottom: 10,
    backgroundColor: '#ff6961',
    borderRadius: 5,
    padding: 10,
  },
  uploadButton: {
    width: "80%",
    marginBottom: 10,
    backgroundColor: '#58a452',
    borderRadius: 5,
    padding: 10,
  },
  buttonText: {
    color: '000', // Color negro para el texto
  },
  card: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 7,
    padding: 10,
    marginBottom: 15,
    elevation: 2,
  },
  cardText: {
    flex: 1,
    color: '#333',
    fontSize: 15,
  },
  icon: {
    width: 20,
    height: 20,
    marginLeft: 10,
  },
  detailCard: {
    backgroundColor: '#eeeeee',
    borderRadius: 7,
    padding: 10,
    marginTop: 5,
  },
  detailText: {
    color: '#333',
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center', // Añadido para centrar verticalmente
    marginVertical: 20, // Ajusta el margen vertical para la imagen
  },
  image: {
    width: '70%', // Cambiado a un porcentaje para adaptarse mejor a la pantalla
    height: undefined, // Mantiene la relación de aspecto
    aspectRatio: 1, // Relación de aspecto cuadrada, ajusta según sea necesario
    borderRadius: 10,
  },
});
