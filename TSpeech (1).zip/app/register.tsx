import { StyleSheet, TextInput, View, Alert, Text } from 'react-native';
import Button from '../components/control/button';
import { useState } from 'react';
import { registroUsuario, Usuario } from "../hooks/dataBaseInteraction";
import { router } from 'expo-router';

export default function Register() {
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#ffffff',
      justifyContent: 'center', // Centra verticalmente
      alignItems: 'center', // Centra horizontalmente
      paddingLeft: 20,
      paddingRight: 20,
    },
    h1: {
      fontSize: 24,
      fontWeight: 'bold', // Cambiado a 'bold' para usar una propiedad válida
      width: '100%',
      textAlign: 'center', // Centra el texto
      marginBottom: 20,
    },
    text: {
      backgroundColor: '#efefef',
      height: 45, // Aumentado para mayor comodidad
      width: '100%',
      borderColor: '#e5e5e5',
      borderWidth: 1,
      borderRadius: 7,
      paddingLeft: 10,
      paddingRight: 10,
      marginBottom: 15,
    },
    button: {
      width: '100%',
      marginTop: 10,
    }
  });

  const [usuario, setUsuario] = useState<string>('');
  const [mail, setMail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [passwordCheck, setPasswordCheck] = useState<string>('');

  const onSave = () => {
    if (!usuario.trim() || !mail.trim() || !password.trim() || !passwordCheck.trim() || (password !== passwordCheck)) {
      return Alert.alert('Información Faltante o Errónea', 'Asegúrese de que el usuario y el email sean válidos; así como que la contraseña y verificación sean iguales.');
    }

    if (!/\S+@\S+\.\S+/.test(mail)) {
      return Alert.alert('Email inválido', 'Por favor ingresa un email válido.');
    }

    registroUsuario({ Usuario: usuario, Mail: mail, Password: password } as Usuario)
      .then((res) => {
        if (!res) return Alert.alert('Error de Base de datos', 'No se pudo guardar el usuario.');
        router.navigate('/login');
      });
  }

  return (
    <View style={styles.container}>
      <Text style={styles.h1}>Crear Cuenta</Text>
      <TextInput placeholder="Usuario" value={usuario} onChangeText={setUsuario} autoCapitalize="words" style={styles.text} />
      <TextInput placeholder="Email" value={mail} onChangeText={setMail} autoCapitalize="none" keyboardType="email-address" style={styles.text} />
      <TextInput placeholder="Contraseña" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" style={styles.text} />
      <TextInput placeholder="Confirmar Contraseña" value={passwordCheck} onChangeText={setPasswordCheck} secureTextEntry autoCapitalize="none" style={styles.text} />

      <Button 
        title='Registro' 
        onPress={onSave} 
        buttonStyles={styles.button} // Estilo del botón
      />
    </View>
  );
}
