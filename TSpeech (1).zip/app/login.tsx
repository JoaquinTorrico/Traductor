import { TextInput, View, Alert, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useState } from 'react';
import { Link, router } from 'expo-router';
import { usuario_login } from '../hooks/dataBaseInteraction';

export default function Register() {
  const styles = {
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#ffffff', // Color de fondo
      padding: 20,
    },
    h1: {
      fontSize: 28,
      fontWeight: 'bold',
      color: '#333', // Color del texto
      width: '100%',
      textAlign: 'center',
      marginBottom: 30,
    },
    text: {
      backgroundColor: '#efefef', // Color de fondo de los campos
      height: 45,
      width: '100%',
      borderColor: '#e5e5e5',
      borderWidth: 1,
      borderRadius: 10,
      paddingLeft: 15,
      paddingRight: 15,
      marginBottom: 20,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 2, // Sombra en Android
    },
    link: {
      marginBottom: 30,
      textAlign: 'right',
      color: '#1F232C', // Cambiado a nuevo color
    },
    button: {
      backgroundColor: '#1F232C', // Cambiado a nuevo color
      borderRadius: 10,
      paddingVertical: 12,
      paddingHorizontal: 20,
      alignItems: 'center',
      elevation: 2, // Sombra en Android
    },
    buttonText: {
      color: '#ffffff', // Color del texto del botón
      fontWeight: 'bold',
      fontSize: 16,
    },
  };

  const [usuario, setUsuario] = useState<string>('');
  const [password, setPassword] = useState<string>('');

  const onLogin = () => {
    if (!usuario.trim() || !password.trim()) {
      return Alert.alert('Información Faltante', 'Por favor verifique la información.');
    }

    usuario_login(usuario, password).then((user) => {
      if (!user) {
        Alert.alert("Usuario Inexistente, verifique la información y vuelva a intentar.");
        return;
      }

      AsyncStorage.setItem('USER', JSON.stringify(user)).then(() => {
        setPassword("");
        setUsuario("");
        router.navigate('/main');
      });
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.h1}>Iniciar Sesión</Text>
      <TextInput 
        placeholder="Usuario" 
        value={usuario} 
        onChangeText={setUsuario} 
        autoCapitalize="words" 
        style={styles.text} 
      />
      <TextInput 
        placeholder="Contraseña" 
        value={password} 
        onChangeText={setPassword} 
        secureTextEntry 
        autoCapitalize="none" 
        style={styles.text} 
      />
        
      <Link href="/recuperaPass" style={styles.link}>¿Olvidaste tu Contraseña?</Link>

      <TouchableOpacity style={styles.button} onPress={onLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
}
