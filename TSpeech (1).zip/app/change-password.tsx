import { StyleSheet, TextInput, View, Alert, Text } from 'react-native';
import Button from '../components/control/button';
import { useState } from 'react';
import { usuario_changepassword } from "../hooks/dataBaseInteraction";
import { router } from 'expo-router';

// Página para cambio de contraseña tras el envío de mail con código de validación.
export default function ChangePassword() {

  const [codigo, setCodigo] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [passwordCheck, setPasswordCheck] = useState<string>('');

  const onSave = () => {
    if (!codigo.trim())
      return Alert.alert('Información Faltante', 'Ingrese el código que envió su email, por favor verifique la carpeta de Spam.');
    if (!password.trim() || !passwordCheck.trim())
      return Alert.alert('Información Faltante', 'Asegúrese de que el código y las contraseñas sean válidos.');
    if (password !== passwordCheck)
      return Alert.alert('Información Faltante', 'Las contraseñas no coinciden.');

    usuario_changepassword(parseInt(codigo), password).then((res) => {
      if (!res) {
        Alert.alert("Verifique información ingresada, Código inválido.");
        return;
      }
      router.navigate('/login');
    });
  }

  return (
    <View style={styles.container}>
      <Text style={styles.h1}>Crear nueva Contraseña</Text>
      <TextInput placeholder="Código" value={codigo} onChangeText={setCodigo} autoCapitalize="none" style={styles.text} />
      <TextInput placeholder="Contraseña" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" style={styles.text} />
      <TextInput placeholder="Confirmar Contraseña" value={passwordCheck} onChangeText={setPasswordCheck} secureTextEntry autoCapitalize="none" style={styles.text} />

      <Button title='Cambio de Contraseña' onPress={onSave} buttonStyles={styles.button} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    justifyContent: 'center', // Centra verticalmente
    alignItems: 'center', // Centra horizontalmente
    paddingLeft: 20,
    paddingRight: 20,
  },
  h1: {
    fontSize: 24,
    fontWeight: 'bold', // Cambiado a 'bold'
    width: '100%',
    textAlign: 'center', // Centra el texto
    marginBottom: 20,
  },
  text: {
    backgroundColor: '#efefef',
    height: 45, // Aumentado para mayor comodidad
    width: '100%',
    borderColor: '#e5e5e5',
    borderWidth: 1,
    borderRadius: 7,
    paddingLeft: 10,
    paddingRight: 10,
    marginBottom: 15,
  },
  button: {
    width: '100%', // Ocupa el ancho completo
    marginTop: 10,
  },
});
