import { TouchableOpacity, StyleSheet, TextInput, View, Alert, Text } from 'react-native';
import Button from '../components/control/button';
import { useState } from 'react';
import { router } from 'expo-router';
import { usuario_generacodigo } from "../hooks/dataBaseInteraction";

export default function Register() {
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#ffffff',
      justifyContent: 'center', // Centra verticalmente
      alignItems: 'center', // Centra horizontalmente
      paddingLeft: 20,
      paddingRight: 20,
    },
    h1: {
      fontSize: 24,
      fontWeight: 'bold', // Cambiado a 'bold'
      width: '100%',
      textAlign: 'center', // Centra el texto
      marginBottom: 20,
    },
    text: {
      backgroundColor: '#efefef',
      height: 45, // Aumentado para mayor comodidad
      width: '100%',
      borderColor: '#e5e5e5',
      borderWidth: 1,
      borderRadius: 7,
      paddingLeft: 10,
      paddingRight: 10,
      marginBottom: 15,
    },
    button: {
      width: '100%', // Ocupa el ancho completo
      marginTop: 10,
    },
  });

  const [mail, setMail] = useState<string>('')

  const onSendMail = () => {
    if (!mail.trim()) 
      return Alert.alert('Información Faltante', 'Por favor verifique la información.');

    usuario_generacodigo(mail).then(res => {
      if (!res) {
        Alert.alert("Ingrese un email registrado")
        return;
      }

      router.navigate('/change-password');
    }).catch(ex => console.error("usuario_generacodigo", ex));
  }

  return (
    <View style={styles.container}>
      <Text style={styles.h1}>¿Olvidaste tu contraseña?</Text>
      <TextInput 
        placeholder="Ingresar email" 
        value={mail} 
        onChangeText={setMail} 
        autoCapitalize="none" 
        keyboardType="email-address" 
        style={styles.text} 
      />

      <Button 
        title='Enviar código' 
        onPress={onSendMail} 
        buttonStyles={styles.button} // Estilo del botón
      />
    </View>
  );
}
