import Button from '../components/control/button';
import { Image, View, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import * as Linking from 'expo-linking';

export default function IndexScreen() {
  const router = useRouter();

  const handleManualPress = () => {
    const manualURL = 'https://drive.google.com/file/d/1LPAqZqB-lWKIqUZOstciHyTx7wrprOCY/view?usp=drive_link'; // Cambia esto por la URL de tu PDF
    Linking.openURL(manualURL).catch(err => console.error('Error al abrir el PDF', err));
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/images/logo.png')}
        style={styles.image}
      />
      <View style={styles.buttonContainer}>
        <Button
          onPress={() => router.navigate('/login')}
          title='Iniciar Sesión'
          buttonStyles={styles.primaryButton}
        />
        <Button
          onPress={() => router.navigate('/register')}
          title='Crear cuenta'
          buttonStyles={styles.secondaryButton}
          textStyles={styles.secondaryButtonText}
        />
      </View>
      <TouchableOpacity onPress={handleManualPress} style={styles.manualLink}>
        <Text style={styles.manualLinkText}>Manual de Usuario</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1F232C',
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    height: 200, // Altura ajustada para mejor encuadre
    width: '80%', // Ancho ajustado para adaptarse a la pantalla
    borderRadius: 10,
    resizeMode: 'contain',
    marginBottom: 20, // Espacio entre la imagen y los botones
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
  },
  primaryButton: {
    width: '80%',
    backgroundColor: '#1F232C',
    borderWidth: 1,
    borderColor: '#FFFFFF',
    marginBottom: 15,
  },
  secondaryButton: {
    width: '80%',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#1F232C',
  },
  secondaryButtonText: {
    color: '#1F232C',
  },
  manualLink: {
    marginTop: 30,
    paddingBottom: 20,
  },
  manualLinkText: {
    color: '#FFFFFF',
    textDecorationLine: 'underline',
    fontSize: 12,
  },
});
